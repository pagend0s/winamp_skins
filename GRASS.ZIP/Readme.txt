

		  --------------------------------
		         WinAmp skin grass
                          PAWE� KONIECZNY
                              2001
		  --------------------------------

	  Je�li jeste� narkomanem to napewno wybierzesz t� skurk�.
 