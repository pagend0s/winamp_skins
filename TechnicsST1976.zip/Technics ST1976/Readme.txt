Technics ST1976 - A WinAmp "Skin" Interface.
===========================================
version 1.0

Version notes:

The first one! Although everything seems fine


Designer's notes:

The interface is based on my personal Technics stereo with backlit panels.


Display notes:

The only display to be used is a a hi-color (16-bit) and even better
smooth a true-color (24- or 32-bit) display. As it is originaly made
in 24-bit.


Acknowedgements:

Thanks goes out to:
Technics, for their excellent equipment.

Enjoy!

/Henrik Mj�berg, hmg@home.se