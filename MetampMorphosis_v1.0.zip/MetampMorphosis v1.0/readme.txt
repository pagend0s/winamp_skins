==========================---------------- Zombie '99
--------------------------===========================
              M E T A M P  m o r p h o s i s     v1.0
--------------------------===========================

Author notes: This is my first attempt at a version 2 
Winamp skin. I originally designed the skin to have a 
blue background and green led display but changed the 
colours after realising the green was too much of a 
blinder on the eyes.

If you want to change the colours back to their 
original state, increase the Hue of each BMP by 18% 
(you can do this in Paint Shop Pro or any useful GFX 
program).

You may distribute this skin freely but please do not 
edit it in any way. Thanks!

--------------------------===========================

Designed in: MS Image Composer 1.5 and PSP 5.00
Best viewed using: 24 bit True Color
Approximate colours count: 1651
Y2K status: Compliant
Song: 'A change' - Sheryl Crow
Mood: :)

Additional files included:
- MetampMorphosis.ffx - settings file for FunkyFX
- MetampMorphosis.vws - presets file for wVis 4.1

--------------------------===========================
 Created during the boring month of February '99 by:
--------------------------===========================

Damien du Toit (Zombie at www.customize.org)
Cape Town, South Africa
E-Mail: damiendt@icon.co.za
URL: http://damiendt.www.icon.co.za/
ICQ: 2099552
IRC: Stipe on is.zanet.org.za - #5fm, #cape_town, #za

--------------------------===========================

"...People seem to pursue money, most commonly. Some 
pursue a political agenda, some pursue fame. I pursue 
the blissful moment of coming up with an idea. That 
makes me very, very happy" - T Kalman, GFX designer

--------------------------===========================
==========================---------------------------