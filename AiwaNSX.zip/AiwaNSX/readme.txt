 **   ***  *   *   **       *  *   **  *   *
*  *   *   *   *  *  *      ** *  *     * *
****   *   * * *  ****      * **   *     *
*  *   *    * *   *  *      *  *    *   * *
*  *  ***   * *   *  *      *  *  **   *   *

AIWA NSX-S v1.0, November 1999.

Thanks for downloading the Aiwa NSX skin for WinAmp.
Big up MP3!!!!! It rules, and you know it!


INSTALLATION:
-------------

If you've got the latest WinAmp, you don't need to unzip this file.
Just stick the zipped file in your Skins directory, and select the
skin from the preferences menu, or using Alt+S.

Get the latest (FREEWARE!) version of WinAmp at www.winamp.com. Now!


NOTES n STUFF:
--------------

This is my first WinAmp skin, and meant to be used with WinAmp 2.0+.
It's based on the Aiwa NSX-S series of Hi-Fi stereos. I did it that
way coz I thought It'd be cool if the MP3 player I use looked the
same as the stereo that's pumping out my choons.

And OK, it's not identical, but the bits that are missing from the
stereo is improvised from the original design.

It comes with:

   1. Main skin
   2. Equalizer skin
   3. Playlist skin
   4. Minibrowser skin (Latest WinAmps have this)

It's got some transparency stuff in it too, but it's very subtle.

All this is my OWN work, created in PSP. So don't just go thieving it.
Thanks again, and hope you like the skin.
Any comments are very welcome.

Author:  Paul Neave
Email:   Paul@Neave.com
Web:     www.neave.com

By the way, does anyone know how to set the text colors for the
minibrowser? If they do, please tell me coz it makes it look a bit
pants right now.

*******************************CHEAT*******************************
DO YOU WANT TO USE PSP5 FOR MORE THAN 60 DAYS? (It WAS free...
I think I got to day 550+/30 on v4 before upgrading!) But PSP5 only
allows 60/30 days use. Then it wants you to order. P'ah! Email me,
and I'll let you know the secret... hehe! That'll teach 'em.
*******************************************************************

