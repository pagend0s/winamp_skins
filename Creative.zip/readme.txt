			 *** Creative iNFRA ***
	 		      WinAmp Skin
		        	  by
			 Sudharga Lenard Neslon        

	First attempt at designing skins. I created this skin using
	my Creative Infra CD-ROM drive. Have fun, Goodbye. 

	Installation:
	 - unzip into your winamp skins folder.
	(ex. c:\Program Files\Winamp\Skins\ )
	 - choose 'select skin' under the options menu of winamp.
	 - select Creative iNFRA and enjoy!

	Thanx for downlaoding my Creative iNFRA skin.
	My E-mail : lenard.n@usa.net
	   FAX : (941) 075 339 821
