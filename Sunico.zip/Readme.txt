Studio Sunico v.1.0 for WinAmp 2.0 or higher by Andrey Semeniouk (andrey@nsys.by). Octember 12, 1999.
Shareware: 1$


   1 .....: INTRODUCTION
   2 .....: INSTALLATION
   3 .....: REGISTRATION
   4 .....: CONTACT



1 ...: INTRODUCTION:

 Thank your for downloading Studio Sunico skin. Skin included all
componentes  of WinAmp (Playlist, Equalizer, Browser).  For  best
results please use WinAmp 2.0 or higher.
 Check  http://sunico.nsys.by/skin/  for   the  latest release of
Studio Sunico skin.

2 ...: INSTALLATION:

1. Copy or move Sunico.zip to the WinAmp Skins directory. 
2. Unzip the file to generate the 'sunico' directory and 
   necessary files for the skin.
3. Launch WinAmp, and type Alt-S for the Skin Browser.
4. Double-click on 'Sunico'.

NOTE: Some recent versions of WinAmp have .ZIP support, if that's
      your  case  then  just  leave  the  .ZIP file on your Skins
      directory.

3 ...: REGISTRATION:

1. All  copyrights  to  Studio Sunico Skin  are exclusively owned
   by the author - Andrey Semeniouk.

2. Anyone  may use this software during a test period of 40 days.
   Following  this  test  period  of 40 days or less, if you wish
   to continue to use Studio Sunico Skin, you MUST register.

3. Once registered, the  user  is granted a non-exclusive license
   to use Studio Sunico Skin on one computer (i.e. a single cpu),
   for  any  legal purpose, at  a  time.  The  registered  Studio
   Sunico Skin may not be rented or eased, but may be permanently
   transferred,  if  the  person  receiving it agrees to terms of
   this license. 
 
4. You  may  not  use,  copy,  emulate,  clone, rent, lease, sell, 
   modify  or  transfer  the  licensed skin, or any subset of the 
   licensed skin, except  as provided for in this  agreement. Any 
   such unauthorized  use shall result in immediate and automatic 
   termination of  this license and may result in criminal and/or 
   civil prosecution.


5. Installing and using  Studio Sunico Skin  signifies acceptance
   of these terms and conditions of the license.

6. If you do not agree with the terms  of  this  license you must
   remove Studio Sunico Skin files from your storage devices  and
   cease to use the product.

See file Register.txt for registration.


4 ...: CONTACT:

URL: http://sunico.nsys.by/skin/

Comments and suggestions to:
 Andrey Semeniouk
 E-mail: andrey@nsys.by
         sunico@nsys.by 