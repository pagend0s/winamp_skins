Thanks for donwloading...
email any questions, suggestions, comments to renfold@hotmail.com
website @ http://www.liquid.a-d-n.com/tim/
big update soon, I hope!  (stated June 9th, 1999)...

hope you enjoy the skin!

timbo
